public class TrainBlock extends TrainEvent {
    
    public TrainBlock(double eventStart, int ID) {
        super(eventStart, ID);
    } // end TrainBlock constructor
} // end TrainBlock class
