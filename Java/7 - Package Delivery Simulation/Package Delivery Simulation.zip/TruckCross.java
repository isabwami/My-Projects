public class TruckCross extends TruckEvent {
    
    public TruckCross(double eventStart, int ID) {
        super(eventStart, ID);
    } // end TruckCross constructor
} // end TruckCross class
