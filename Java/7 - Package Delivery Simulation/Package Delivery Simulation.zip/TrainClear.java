public class TrainClear extends TrainEvent {
    
    public TrainClear(double eventStart, int ID) {
        super(eventStart, ID);
    } // end TrainClear constructor
} // end TrainClear class
