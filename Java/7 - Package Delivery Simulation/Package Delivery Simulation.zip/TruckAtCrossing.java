public class TruckAtCrossing extends TruckEvent {
    
    public TruckAtCrossing(double eventStart, int ID) {
        super(eventStart, ID);
    } // end TruckAtCrossing constructor
} // end TruckAtCrossing class
