public class TruckEvent extends Event {

    public TruckEvent(double eventStart, int ID) {
        super(eventStart, ID);
    } // end TruckEvent constructor
} // end TruckEvent class
