public class TruckEnd extends TruckEvent {
    
    public TruckEnd(double eventStart, int ID) {
        super(eventStart, ID);
    } // end TruckEnd constructor
} // end TruckEnd class
