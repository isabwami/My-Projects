public class TrainEvent extends Event {
    
    public TrainEvent(double eventStart, int ID) {
        super(eventStart, ID);
    } // end TrainEvent constructor
} // end TrainEvent class
