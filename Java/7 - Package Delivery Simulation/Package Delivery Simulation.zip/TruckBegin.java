public class TruckBegin extends TruckEvent {
    
    public TruckBegin(double eventStart, int ID) {
        super(eventStart, ID);
    } // end TruckBegin constructor
} // end TruckBegin class
